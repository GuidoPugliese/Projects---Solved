var nombreColores = ['White', 'LightYellow',
  'LemonChiffon', 'LightGoldenrodYellow', 'PapayaWhip', 'Moccasin', 'PeachPuff', 'PaleGoldenrod', 'Bisque', 'NavajoWhite', 'Wheat', 'BurlyWood', 'Tan',
  'Khaki', 'Yellow', 'Gold', 'Orange', 'DarkOrange', 'OrangeRed', 'Tomato', 'Coral', 'DarkSalmon', 'LightSalmon', 'LightCoral', 'Salmon', 'PaleVioletRed',
  'Pink', 'LightPink', 'HotPink', 'DeepPink', 'MediumVioletRed', 'Crimson', 'Red', 'FireBrick', 'DarkRed', 'Maroon',
  'Brown', 'Sienna', 'SaddleBrown', 'IndianRed', 'RosyBrown',
  'SandyBrown', 'Goldenrod', 'DarkGoldenrod', 'Peru',
  'Chocolate', 'DarkKhaki', 'DarkSeaGreen', 'MediumAquaMarine',
  'MediumSeaGreen', 'SeaGreen', 'ForestGreen', 'Green', 'DarkGreen', 'OliveDrab', 'Olive', 'DarkOliveGreen', 'YellowGreen', 'LawnGreen',
  'Chartreuse', 'GreenYellow', 'Lime', 'SpringGreen', 'LimeGreen',
  'LightGreen', 'PaleGreen', 'PaleTurquoise',
  'AquaMarine', 'Cyan', 'Turquoise', 'MediumTurquoise', 'DarkTurquoise', 'DeepSkyBlue',
  'LightSeaGreen', 'CadetBlue', 'DarkCyan', 'Teal', 'Steelblue', 'LightSteelBlue', 'Honeydew', 'LightCyan',
  'PowderBlue', 'LightBlue', 'SkyBlue', 'LightSkyBlue',
  'DodgerBlue', 'CornflowerBlue', 'RoyalBlue', 'SlateBlue',
  'MediumSlateBlue', 'DarkSlateBlue', 'Indigo', 'Purple', 'DarkMagenta', 'Blue',
  'MediumBlue', 'DarkBlue', 'Navy', 'Thistle',
  'Plum', 'Violet', 'Orchid', 'DarkOrchid', 'Fuchsia', 'Magenta', 'MediumOrchid',
  'BlueViolet', 'DarkViolet', 'DarkOrchid',
  'MediumPurple', 'Lavender', 'Gainsboro', 'LightGray', 'Silver', 'DarkGray', 'Gray',
  'DimGray', 'LightSlateGray', 'DarkSlateGray', 'Black'
];

// Variables
var colorPersonalizado = document.getElementById('color-personalizado');
var paleta = document.getElementById('paleta')
var grillaPixel = document.getElementById('grilla-pixeles');
var colorSeleccionado = 'white';
var pixel = document.getElementsByClassName("pixel")
var estadoMouse = false;


document.body.onmousedown = function() {
  estadoMouse = true;
}
document.body.onmouseup = function() {
  estadoMouse = false;
}

// Rueda de colores

colorPersonalizado.addEventListener('change',
  (function() {
    // Se guarda el color de la rueda en colorActual
    colorActual = colorPersonalizado.value;
    // Completar para que cambie el indicador-de-color al colorActual
    indicadorDeColor.style.backgroundColor = colorActual;
    colorSeleccionado = colorActual;
  })
);


colorPaleta = document.getElementsByClassName('color-paleta')
indicadorDeColor = document.getElementById('indicador-de-color')

//Color actual
function actualizarColor(color){
  return function() {colorSeleccionado = color;
    indicadorDeColor.style.backgroundColor = color;
  }
}

//Paleta
for(i = 0; i < nombreColores.length ; i++){
  var nuevoDiv = document.createElement('div');
  nuevoDiv.style.backgroundColor = nombreColores[i];
  nuevoDiv.className = 'color-paleta';
  nuevoDiv.addEventListener('click', actualizarColor(nombreColores[i]));
  paleta.appendChild(nuevoDiv);
}

//Grilla
for(i = 0; i < 1750; i++){
  var nuevoPixel = document.createElement('div');
  grillaPixel.appendChild(nuevoPixel);
  nuevoPixel.addEventListener('click', pintar);
  nuevoPixel.addEventListener('mouseover', pintarHover);
  nuevoPixel.className = 'pixel';
}

//Pintar y Hover
function pintar(e){
e.target.style.backgroundColor = colorSeleccionado;
}

function pintarHover(e){
  if(estadoMouse == true){
  e.target.style.backgroundColor = colorSeleccionado;
}
}

//Borrar grilla
function borrarTodo(){
$(grillaPixel).fadeOut(500);
setTimeout(function(){for(i = 0; i < pixel.length; i++){
  pixel[i].style.backgroundColor = ('white');
}}, 100)
$(grillaPixel).fadeIn(500);
}



var borrar = document.getElementById('borrar')
borrar.addEventListener('click', borrarTodo)

var guardar = document.getElementById('guardar')
guardar.addEventListener('click', guardarPixelArt)

var loadBatman = document.getElementById('batman')
loadBatman.addEventListener('click', cargarHeroe)

var loadWonder = document.getElementById('wonder')
loadWonder.addEventListener('click', cargarHeroe)

var loadFlash = document.getElementById('flash')
loadFlash.addEventListener('click', cargarHeroe)

var loadInvisible = document.getElementById('invisible')
loadInvisible.addEventListener('click', cargarHeroe)

function cargarHeroe(e){
  var Heroe = window[e.target.id]
  cargarSuperheroe(Heroe)
}







